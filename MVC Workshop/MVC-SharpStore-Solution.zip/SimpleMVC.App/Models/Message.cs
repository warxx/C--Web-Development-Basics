﻿namespace SharpStore.Models
{
    public class Message
    {
        public int Id { get; set; }

        public string Email { get; set; }

        public string Subject { get; set; }

        public string MessageText { get; set; }
    }
}
