﻿namespace SharpStore.BindingModels
{
    public class PurchaseBindingModel
    {
        public int KnifeId { get; set; }

        public string BuyerName { get; set; }

        public string BuyerPhone { get; set; }

        public string BuyerAddress { get; set; }

        public string DeliveryType { get; set; }
    }
}
