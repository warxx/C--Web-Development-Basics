﻿namespace SharpStore.BindingModels
{
    public class MessageBinding
    {
        public string Email { get; set; }

        public string Subject { get; set; }

        public string Message { get; set; }
    }
}
