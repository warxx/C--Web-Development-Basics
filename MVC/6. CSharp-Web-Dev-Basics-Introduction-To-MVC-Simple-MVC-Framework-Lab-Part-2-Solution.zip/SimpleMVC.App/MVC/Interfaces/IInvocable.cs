﻿namespace SimpleMVC.App.MVC.Interfaces
{
    public interface IInvocable
    {
        string Invoke();
    }
}
