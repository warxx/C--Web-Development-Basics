﻿namespace SimpleMVC.App.ViewModels
{
    public class GreetViewModel
    {
        public string SessionId { get; set; }
    }
}
