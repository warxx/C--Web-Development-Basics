﻿namespace SimpleMVC.App.ViewModels
{
    public class UserViewModel
    {
        public string Username { get; set; }
    }
}
