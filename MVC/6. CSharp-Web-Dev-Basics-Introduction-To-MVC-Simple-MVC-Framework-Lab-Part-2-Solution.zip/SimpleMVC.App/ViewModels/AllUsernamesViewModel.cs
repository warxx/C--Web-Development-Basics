﻿using System.Collections.Generic;

namespace SimpleMVC.App.ViewModels
{
    public class AllUsernamesViewModel
    {
        public IList<string> Usernames { get; set; }
    }
}

