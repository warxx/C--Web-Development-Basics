﻿namespace PizzaForum.BindingModels
{
    public class LoginUserBindingModel
    {
        public string Credential { get; set; }

        public string Password { get; set; }
    }
}
