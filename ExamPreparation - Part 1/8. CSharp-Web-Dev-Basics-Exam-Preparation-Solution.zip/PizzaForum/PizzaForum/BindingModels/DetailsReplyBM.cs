﻿namespace PizzaForum.BindingModels
{
    class DetailsReplyBM
    {
        public string Content { get; set; }

        public string ImageUrl { get; set; }

        public string TopicTitle { get; set; }
    }
}
