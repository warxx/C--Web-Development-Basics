﻿namespace PizzaForum.BindingModels
{
    public class NewTopicBindingModel
    {
        public string Title { get; set; }

        public string Content { get; set; }

        public string Category { get; set; }
    }
}
