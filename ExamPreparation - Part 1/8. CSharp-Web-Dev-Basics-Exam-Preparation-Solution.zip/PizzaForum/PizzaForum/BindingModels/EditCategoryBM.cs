﻿namespace PizzaForum.BindingModels
{
    public class EditCategoryBM
    {
        public int CategoryId { get; set; }

        public string CategoryName { get; set; }
    }
}
