﻿namespace PizzaForum.BindingModels
{
    public class NewCategoryBindingModel
    {
        public string Name { get; set; }
    }
}
