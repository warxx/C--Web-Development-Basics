﻿namespace PizzaForum.ViewModels
{
    public class LoggedInUserViewModel
    {
        public string Username { get; set; }
        
    }
}
