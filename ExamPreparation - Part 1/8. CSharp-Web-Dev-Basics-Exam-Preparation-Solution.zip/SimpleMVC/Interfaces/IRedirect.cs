﻿namespace SimpleMVC.App.MVC.Interfaces
{
    public interface IRedirect
    {
        string Location { get; set; }
    }
}
